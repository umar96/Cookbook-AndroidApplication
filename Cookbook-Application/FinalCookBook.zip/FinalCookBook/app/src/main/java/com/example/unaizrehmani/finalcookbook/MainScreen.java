package com.example.unaizrehmani.finalcookbook;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainScreen extends AppCompatActivity implements Serializable{

    //Ingredients and Recipes.

    ArrayList<Ingredient> _cookBookIngredients = new ArrayList<Ingredient>();
    ArrayList<Recipe> _cookBookRecipes = new ArrayList<Recipe>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        //If instantiated first time.
        Bundle bundle = getIntent().getExtras();

        try {
            MainScreen mainScreen = (MainScreen) bundle.getSerializable("cookBook");
            _cookBookRecipes = mainScreen.get_cookBookRecipes();
            _cookBookIngredients = mainScreen.get_cookBookIngredients();

        } catch(Exception e){
            populateCookBookIngredients();
            populateCookBookRecipes();
        }

    }

    public void clickFindRecipes(View view){
        Intent intent = new Intent(this,findRecipe.class);

        Bundle bundle = new Bundle();

        bundle.putSerializable("cookBook",this);

        intent.putExtras(bundle);

        startActivity(intent);
    }

    public void clickEditIngredients(View view){
        Intent intent = new Intent(this,EditIngredients.class);

        Bundle bundle = new Bundle();

        bundle.putSerializable("cookBook",this);

        intent.putExtras(bundle);

        startActivity(intent);
    }

    public void clickEditRecipes(View view){
        Intent intent = new Intent(this,EditRecipes.class);

        Bundle bundle = new Bundle();

        bundle.putSerializable("cookBook",this);

        intent.putExtras(bundle);

        startActivity(intent);
    }

    public ArrayList<Ingredient> get_cookBookIngredients() {
        return _cookBookIngredients;
    }

    public void set_cookBookIngredients(ArrayList<Ingredient> _cookBookIngredients) {
        this._cookBookIngredients = _cookBookIngredients;
    }

    public ArrayList<Recipe> get_cookBookRecipes() {
        return _cookBookRecipes;
    }

    public void set_cookBookRecipes(ArrayList<Recipe> _cookBookRecipes) {
        this._cookBookRecipes = _cookBookRecipes;
    }

    public void add_cookBookIngredient(String ingredient){

        if(!_cookBookIngredients.contains(new Ingredient(ingredient))) {
            _cookBookIngredients.add(new Ingredient(ingredient));

            Collections.sort(_cookBookIngredients, new Comparator<Ingredient>() {
                @Override
                public int compare(Ingredient s1, Ingredient s2) {
                    return s1.get_IngredientName().compareToIgnoreCase(s2.get_IngredientName());
                }
            });
        }
    }

    public void delete_cookBookIngredient(String ingredient){
        if(_cookBookIngredients.contains(new Ingredient(ingredient))){
            _cookBookIngredients.remove(new Ingredient(ingredient));


        }
    }

    public void add_cookBookRecipe(Recipe recipe){
        _cookBookRecipes.add(recipe);

        Collections.sort(_cookBookRecipes, new Comparator<Recipe>() {
            @Override
            public int compare(Recipe s1, Recipe s2) {
                return s1.getRecipeName().compareToIgnoreCase(s2.getRecipeName());
            }
        });
    }

    public void delete_cookBookRecipe(String recipeName){
        for(int i = 0; i<_cookBookRecipes.size(); i++){
            if(_cookBookRecipes.get(i).getRecipeName().equals(recipeName)){
                _cookBookRecipes.remove(i);
            }
        }
    }

    private void populateCookBookIngredients(){
        //Let's populate some default ingredients for cookbook.

        //Populates Ingredients objects.
        _cookBookIngredients.add(new Ingredient ("Chicken"));
        _cookBookIngredients.add(new Ingredient ("Water"));
        _cookBookIngredients.add(new Ingredient ("Salt"));
        _cookBookIngredients.add(new Ingredient ("Beef"));
        _cookBookIngredients.add(new Ingredient ("Lettuce"));
        _cookBookIngredients.add(new Ingredient ("Tomatoes"));
        _cookBookIngredients.add(new Ingredient ("Ketchup"));
        _cookBookIngredients.add(new Ingredient ("Mayonnaise"));
        _cookBookIngredients.add(new Ingredient ("Pepper"));
        _cookBookIngredients.add(new Ingredient ("Eggs"));
        _cookBookIngredients.add(new Ingredient ("Cheese"));
        _cookBookIngredients.add(new Ingredient ("Milk"));
        _cookBookIngredients.add(new Ingredient ("Pasta"));
        _cookBookIngredients.add(new Ingredient ("Salsa"));
        _cookBookIngredients.add(new Ingredient ("Walnuts"));
        _cookBookIngredients.add(new Ingredient ("Almonds"));
        _cookBookIngredients.add(new Ingredient ("Rice"));
        _cookBookIngredients.add(new Ingredient ("Potatoes"));
        _cookBookIngredients.add(new Ingredient ("Butter"));
        _cookBookIngredients.add(new Ingredient ("Oil"));
        _cookBookIngredients.add(new Ingredient ("Orange"));
        _cookBookIngredients.add(new Ingredient ("Banana"));
        _cookBookIngredients.add(new Ingredient ("Grapes"));
        _cookBookIngredients.add(new Ingredient ("Strawberry"));
        _cookBookIngredients.add(new Ingredient ("Cranberry"));
        _cookBookIngredients.add(new Ingredient ("Cucumber"));
        _cookBookIngredients.add(new Ingredient ("Radish"));
        _cookBookIngredients.add(new Ingredient ("Olives"));
        _cookBookIngredients.add(new Ingredient ("Bread"));
        _cookBookIngredients.add(new Ingredient ("Sugar"));
        _cookBookIngredients.add(new Ingredient ("Lemon"));
        _cookBookIngredients.add(new Ingredient ("Parsley"));

        Collections.sort(_cookBookIngredients,new Comparator<Ingredient>() {
            @Override
            public int compare(Ingredient s1, Ingredient s2) {
                return s1.get_IngredientName().compareToIgnoreCase(s2.get_IngredientName());
            }
        });
    }

    //Default Recipes entered here and sorted.
    private void populateCookBookRecipes(){
        //let's populate some default recipes here for cookbook.
        //********************CHICKEN NOODLE SOUP
        ArrayList<Ingredient> chickenNoodleSoupIngredients = new ArrayList<Ingredient>();
        chickenNoodleSoupIngredients.add(new Ingredient("Chicken"));
        chickenNoodleSoupIngredients.add(new Ingredient("Water"));
        chickenNoodleSoupIngredients.add(new Ingredient("Salt"));
        chickenNoodleSoupIngredients.add(new Ingredient("Pepper"));
        chickenNoodleSoupIngredients.add(new Ingredient("Noodles"));
        chickenNoodleSoupIngredients.add(new Ingredient("Soy sauce"));

        ArrayList<String> chickenNoodleSoupDirections = new ArrayList<String>();
        chickenNoodleSoupDirections.add("Add Chicken to boiling hot water");
        chickenNoodleSoupDirections.add("Add a table spoon of salt and pepper each.");
        chickenNoodleSoupDirections.add("Add a cup of noodles to the boiling hot water.");
        chickenNoodleSoupDirections.add("After 10 minutes, remove and serve with soy sauce.");

        Recipe chickenNoodleSoup = new Recipe("Chicken Noodle Soup", "Lunch", "American",
                chickenNoodleSoupIngredients, chickenNoodleSoupDirections);

        _cookBookRecipes.add(chickenNoodleSoup);

        //*********************BLT SAMMICH
        ArrayList<Ingredient> bltIngredients = new ArrayList<Ingredient>();
        bltIngredients.add(new Ingredient("Bread"));
        bltIngredients.add(new Ingredient("Mayonnaise"));
        bltIngredients.add(new Ingredient("Salt"));
        bltIngredients.add(new Ingredient("Lettuce"));
        bltIngredients.add(new Ingredient("Beef"));
        bltIngredients.add(new Ingredient("Tomatoes"));

        ArrayList<String> bltDirections = new ArrayList<String>();
        bltDirections.add("Toast Bread");
        bltDirections.add("Add mayonnaise on each side of the toasts");
        bltDirections.add("Add lettuce on each side");
        bltDirections.add("Add beef, salt, tomatoes and eat it.");

        Recipe blt = new Recipe("BLT", "Lunch", "American",
                bltIngredients, bltDirections);

        _cookBookRecipes.add(blt);

        Collections.sort(_cookBookRecipes,new Comparator<Recipe>() {
            @Override
            public int compare(Recipe s1, Recipe s2) {
                return s1.getRecipeName().compareToIgnoreCase(s2.getRecipeName());
            }
        });
    }

}
